<!DOCTYPE html>
<html lang="en">
<head>
  <title> PHP ajax crud </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
    <style>
        table ,th, td {
            border: 1px solid #ddd;
        }
    
    </style>
</head>
<body>

    <div class="container">
        <div class="text-center mb-5">
            <h1>PHP <span> Ajax </span> Crud</h1>
        </div>

        <!-- INSER FIELD -->
        <form id="addForm">
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <label> First Name </label>
                        <input type="text"  class="form-control" id="first_name"  placeholder="First Name" required>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group">
                        <label> Last Name </label>
                        <input type="text" class="form-control" id="last_name" placeholder="Last Name" required>
                    </div>
                </div> 
                <div class="col">
                    <div class="form-group sv-btn">
                        <button type="button" class="btn btn-info mt-4" id="save-btn" >
                            Save
                        </button>
                    </div>
                </div>  
            </div>
        </form>

        <br>

        <!-- SHOW DATA -->
        <div id="table-data">
        </div>
    </div>

        <!-- SUCCESS & ERROR MESSAGE -->
    <div id="error-message"></div>
    <div id="success-message"></div>

        <!-- EDIT MODAL -->
    <div id="modal">
        <div id="modal-form">
            <h2>Edit Form</h2>
            <table cellpadding="10px" width="100%">
            </table>
            <div id="close-btn">X</div>
        </div>
    </div>


	<script src="js/jquery.js"></script>
    
    <script type="text/javascript">
        $(document).ready(function(){
            // Load Data From Database 
           function loadTable(){
            $.ajax({
                    url: "ajax-load.php",
                    type: "POST",
                    success: function(data){
                        $("#table-data").html(data);
                    }
                });
           }
           loadTable();

            // Insert New Records
            $("#save-btn").on("click",function(e){
                e.preventDefault();
                var fname = $("#first_name").val();
                var lname = $("#last_name").val();

                if(fname == "" || lname == ""){
                    $("#error-message").html("All fields are required.").slideDown();
                    $("#success-message").slideUp();
                }else{
                    $.ajax({
                    url: "ajax-insert.php",
                    type : "POST",
                    data : {first_name:fname, last_name: lname},
                    success : function(data){
                        if(data == 1){
                            loadTable();
                            $("#addForm").trigger("reset");
                            $("#success-message").html("Data Inserted Successfully.").slideDown();
                            $("#error-message").slideUp();
                        }else{
                            $("#error-message").html("Can't Save Record.").slideDown();
                            $("#success-message").slideUp();
                        }
                    }
                    });
                }
            });

            //Delete Records
            $(document).on("click",".delete-btn", function(){
                if(confirm("Do you really want to delete this record ?")){
                    var studentId = $(this).data("id");
                    // alert(studentId)
                    var element = this;

                    $.ajax({
                    url: "ajax-delete.php",
                    type : "POST",
                    data : {id : studentId},
                    success : function(data){
                        if(data == 1){
                            $(element).closest("tr").fadeOut();
                        }
                    }
                    });
                }
            });

            //Show Modal Box
            $(document).on("click",".edit-btn", function(){
                $("#modal").show();
                var studentId = $(this).data("eid");

                $.ajax({
                    url: "load-update-form.php",
                    type: "POST",
                    data: {id: studentId },
                    success: function(data) {
                    $("#modal-form table").html(data);
                    }
                })
            });

            //Hide Modal Box
            $("#close-btn").on("click",function(){
                $("#modal").hide();
            });

            
            //Save Update Form
            $(document).on("click","#edit-submit", function(){
                var stuId = $("#edit-id").val();
                var fname = $("#edit-fname").val();
                var lname = $("#edit-lname").val();

                $.ajax({
                url: "ajax-update-form.php",
                type : "POST",
                data : {id: stuId, first_name: fname, last_name: lname},
                success: function(data) {
                    if(data == 1){
                    $("#modal").hide();
                    loadTable();
                    }
                }
                })
            });
        


        });
    </script>


</body>
</html>